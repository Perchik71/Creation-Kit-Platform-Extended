// CKPEEmptyPlugin - Is a template for creating new plugins for CKPE.
